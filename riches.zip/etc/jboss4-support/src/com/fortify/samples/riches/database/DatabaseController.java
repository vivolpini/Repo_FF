/***********************************************************************
 * (C) Copyright 2005  Fortify Software Inc.   All Rights Reserved.
 *
 *  Copyright 2005 Fortify Software, Inc. All rights reserved.
 *  This software is provided solely in connection with the terms
 *  of the license agreement.  Any other use without the prior express
 *  written permission of Fortify Software is completely prohibited.
 ************************************************************************/

package com.fortify.samples.riches.database;

import javax.servlet.ServletContextListener;
import javax.servlet.ServletContextEvent;
/* $File: //depot/releases/twopi/animal/demo/java/riches/etc/jboss4-support/src/com/fortify/samples/riches/database/DatabaseController.java $ 
 * Created by: adam on Aug 8, 2005
 *
 * Details of last change:
 * $Author: sean $
 * $DateTime: 2011/03/10 14:10:21 $
 * $Revision: #1 $
 * $Change: 112624 $
 */

public class DatabaseController implements ServletContextListener {

	// do nothing, the functionality normally provided in this class is handled by JBoss MBeans

	public void contextInitialized(ServletContextEvent servletContextEvent) { }
	public void contextDestroyed(ServletContextEvent servletContextEvent) {	}
}

